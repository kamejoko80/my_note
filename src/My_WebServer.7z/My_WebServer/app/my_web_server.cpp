#include <user_config.h>
#include <SmingCore/SmingCore.h>
#include <AppSettings.h>

HttpServer server;
FTPServer ftp;

BssList networks;
String network, password;
Timer connectionTimer;
Timer printTimer;
char str[17];    

void onPrintSystemTime() {
	//Serial.print("Local Time    : ");
	//Serial.println(SystemClock.getSystemTimeString());
	//Serial.print("UTC Time: ");
	//Serial.println(SystemClock.getSystemTimeString(eTZ_UTC));

#if 0    
    int8_t Hour;
	int8_t Minute;
	int8_t Second;
    DateTime datetime = SystemClock.now();
    
    debugf("Hour  : %d\r\n", datetime.Hour);
    debugf("Minute: %d\r\n", datetime.Minute);
    debugf("Second: %d\r\n", datetime.Second);
#endif    
}

void getHTTPTime(char *str)
{
    char Year[5];
    char Month[3];
    char Day[3];
    char Hour[3];
    char Minute[3];
    int n = 0;
    
    memset(str, 0, 17);
    
    /* Get current datetime */
    DateTime datetime = SystemClock.now();
   
    Serial.println("SystemClock.now :");
    Serial.println(datetime.toFullDateTimeString());
   
    // Year-Month-DayTHour:Minute   
    itoa(datetime.Year, Year, 10);  
    memcpy(str + n, Year, strlen(Year));
    n = n + strlen(Year);
    memcpy(str + n, "-", 1);
    n = n + 1;
    
    /* Update bug Month + 1 instead Month */
    if((datetime.Month + 1) < 10)
    {
        memcpy(str + n, "0", 1);
        n = n + 1;     
    }
    itoa(datetime.Month + 1, Month, 10);    
    memcpy(str + n, Month, strlen(Month));
    n = n + strlen(Month);
    memcpy(str + n, "-", 1);
    n = n + 1;  
  
    if(datetime.Day < 10)
    {
        memcpy(str + n, "0", 1);
        n = n + 1;     
    } 
    itoa(datetime.Day, Day, 10);
    memcpy(str + n, Day, strlen(Day));
    n = n + strlen(Day);
    memcpy(str + n, "T", 1);
    n = n + 1;  
 
    if(datetime.Hour < 10)
    {
        memcpy(str + n, "0", 1);
        n = n + 1;     
    }
    itoa(datetime.Hour, Hour, 10);
    memcpy(str + n, Hour, strlen(Hour));
    n = n + strlen(Hour);
    memcpy(str + n, ":", 1);
    n = n + 1;  
  
    if(datetime.Minute < 10)
    {
        memcpy(str + n, "0", 1);
        n = n + 1;     
    }  
    itoa(datetime.Minute, Minute, 10);
    memcpy(str + n, Minute, strlen(Minute));
    n = n + strlen(Minute);

    debugf("HTTP Time : %s \r\n", str);   
}

void onIndex(HttpRequest &request, HttpResponse &response)
{
	if (request.getRequestMethod() == RequestMethod::POST)
	{
        Serial.println("-----------------POST---------------------");
      
        String StrTimeStamp = request.getPostParameter("TimeStamp");
        
        Serial.println(StrTimeStamp);
        
        if(StrTimeStamp!=NULL)
        {
            Serial.println("-----Updated System clock------");
            // set time zone hourly difference to UTC
            SystemClock.setTimeZone(7);
            SystemClock.setTime(StrTimeStamp.toInt());
            
            Serial.print("Local Time after set : ");
	        Serial.println(SystemClock.getSystemTimeString());
            
            /* Start print timer */
            printTimer.initializeMs(1000, onPrintSystemTime).start();
        }
        
                       
		AppSettings.dhcp = request.getPostParameter("dhcp") == "1";
		AppSettings.ip = request.getPostParameter("ip");
		AppSettings.netmask = request.getPostParameter("netmask");
		AppSettings.gateway = request.getPostParameter("gateway");
		debugf("Updating IP settings: %d", AppSettings.ip.isNull());
		AppSettings.save();
	}
    
	TemplateFileStream *tmpl = new TemplateFileStream("index.html");
	auto &vars = tmpl->variables();

	bool dhcp = WifiStation.isEnabledDHCP();
       
	vars["dhcpon"] = dhcp ? "checked='checked'" : "";
	vars["dhcpoff"] = !dhcp ? "checked='checked'" : "";
      

    Serial.print("Local Time before update : ");
	Serial.println(SystemClock.getSystemTimeString());   
      
    /* Get current time */ 
    getHTTPTime(str);
    
    /* Update date time content */       
    vars["datetime"].setString(str, 16);
    
    Serial.println("Var DateTime = ");
    Serial.println(vars["datetime"]);
   
 
	if (!WifiStation.getIP().isNull())
	{
		vars["ip"] = WifiStation.getIP().toString();
		vars["netmask"] = WifiStation.getNetworkMask().toString();
		vars["gateway"] = WifiStation.getNetworkGateway().toString();
	}
	else
	{
		vars["ip"] = "192.168.1.77";
		vars["netmask"] = "255.255.255.0";
		vars["gateway"] = "192.168.1.1";
	}

	response.sendTemplate(tmpl); // will be automatically deleted
}

void onIpConfig(HttpRequest &request, HttpResponse &response)
{
	if (request.getRequestMethod() == RequestMethod::POST)
	{
		AppSettings.dhcp = request.getPostParameter("dhcp") == "1";
		AppSettings.ip = request.getPostParameter("ip");
		AppSettings.netmask = request.getPostParameter("netmask");
		AppSettings.gateway = request.getPostParameter("gateway");
		debugf("Updating IP settings: %d", AppSettings.ip.isNull());
		AppSettings.save();
	}

	TemplateFileStream *tmpl = new TemplateFileStream("index.html");
	auto &vars = tmpl->variables();

	bool dhcp = WifiStation.isEnabledDHCP();
	vars["dhcpon"] = dhcp ? "checked='checked'" : "";
	vars["dhcpoff"] = !dhcp ? "checked='checked'" : "";

	if (!WifiStation.getIP().isNull())
	{
		vars["ip"] = WifiStation.getIP().toString();
		vars["netmask"] = WifiStation.getNetworkMask().toString();
		vars["gateway"] = WifiStation.getNetworkGateway().toString();
	}
	else
	{
		vars["ip"] = "192.168.1.77";
		vars["netmask"] = "255.255.255.0";
		vars["gateway"] = "192.168.1.1";
	}

	response.sendTemplate(tmpl); // will be automatically deleted
}

void onFile(HttpRequest &request, HttpResponse &response)
{
	String file = request.getPath();
	if (file[0] == '/')
		file = file.substring(1);

	if (file[0] == '.')
		response.forbidden();
	else
	{
		response.setCache(86400, true); // It's important to use cache for better performance.
		response.sendFile(file);
	}
}

void onAjaxNetworkList(HttpRequest &request, HttpResponse &response)
{
	JsonObjectStream* stream = new JsonObjectStream();
	JsonObject& json = stream->getRoot();

	json["status"] = (bool)true;

	bool connected = WifiStation.isConnected();
	json["connected"] = connected;
	if (connected)
	{
		// Copy full string to JSON buffer memory
		json.addCopy("network", WifiStation.getSSID());
	}

	JsonArray& netlist = json.createNestedArray("available");
	for (int i = 0; i < networks.count(); i++)
	{
		if (networks[i].hidden) continue;
		JsonObject &item = netlist.createNestedObject();
		item.add("id", (int)networks[i].getHashId());
		// Copy full string to JSON buffer memory
		item.addCopy("title", networks[i].ssid);
		item.add("signal", networks[i].rssi);
		item.add("encryption", networks[i].getAuthorizationMethodName());
	}

	response.setAllowCrossDomainOrigin("*");
	response.sendJsonObject(stream);
}

void makeConnection()
{
	WifiStation.enable(true);
	WifiStation.config(network, password);

	AppSettings.ssid = network;
	AppSettings.password = password;
	AppSettings.save();

	network = ""; // task completed
}

void onAjaxConnect(HttpRequest &request, HttpResponse &response)
{
	JsonObjectStream* stream = new JsonObjectStream();
	JsonObject& json = stream->getRoot();

	String curNet = request.getPostParameter("network");
	String curPass = request.getPostParameter("password");

	bool updating = curNet.length() > 0 && (WifiStation.getSSID() != curNet || WifiStation.getPassword() != curPass);
	bool connectingNow = WifiStation.getConnectionStatus() == eSCS_Connecting || network.length() > 0;

	if (updating && connectingNow)
	{
		debugf("wrong action: %s %s, (updating: %d, connectingNow: %d)", network.c_str(), password.c_str(), updating, connectingNow);
		json["status"] = (bool)false;
		json["connected"] = (bool)false;
	}
	else
	{
		json["status"] = (bool)true;
		if (updating)
		{
			network = curNet;
			password = curPass;
			debugf("CONNECT TO: %s %s", network.c_str(), password.c_str());
			json["connected"] = false;
			connectionTimer.initializeMs(1200, makeConnection).startOnce();
		}
		else
		{
			json["connected"] = WifiStation.isConnected();
			debugf("Network already selected. Current status: %s", WifiStation.getConnectionStatusName());
		}
	}

	if (!updating && !connectingNow && WifiStation.isConnectionFailed())
		json["error"] = WifiStation.getConnectionStatusName();

	response.setAllowCrossDomainOrigin("*");
	response.sendJsonObject(stream);
}

void startWebServer()
{
	server.listen(80);
	server.addPath("/", onIndex);
	//server.addPath("/ipconfig", onIpConfig);
    //server.addPath("/", onIpConfig);
	server.addPath("/ajax/get-networks", onAjaxNetworkList);
	server.addPath("/ajax/connect", onAjaxConnect);
	server.setDefaultHandler(onFile);
}

void startFTP()
{
#if 0
	if (!fileExist("index.html"))
		fileSetContent("index.html", "<h3>Please connect to FTP and upload files from folder 'web/build' (details in code)</h3>");
#endif
	// Start FTP server
	ftp.listen(21);
	ftp.addUser("admin", "admin"); // FTP account
}

// Will be called when system initialization was completed
void startServers()
{
	startFTP();
	startWebServer();
}

void networkScanCompleted(bool succeeded, BssList list)
{
	if (succeeded)
	{
		for (int i = 0; i < list.count(); i++)
			if (!list[i].hidden && list[i].ssid.length() > 0)
				networks.add(list[i]);
	}
	networks.sort([](const BssInfo& a, const BssInfo& b){ return b.rssi - a.rssi; } );
}

void init()
{    
	Serial.begin(SERIAL_BAUD_RATE); // 115200 by default
      
	//Serial.systemDebugOutput(true); // Enable debug output to serial
	AppSettings.load();
    
	WifiStation.enable(true);
	if (AppSettings.exist())
	{
		WifiStation.config(AppSettings.ssid, AppSettings.password);
		if (!AppSettings.dhcp && !AppSettings.ip.isNull())
			WifiStation.setIP(AppSettings.ip, AppSettings.netmask, AppSettings.gateway);
	}
	WifiStation.startScan(networkScanCompleted);

	// Start AP for configuration
	WifiAccessPoint.enable(true);
	WifiAccessPoint.config("Sming Configuration", "", AUTH_OPEN);

 	// Station - WiFi client
	WifiStation.enable(true);
	WifiStation.config("phuongkhanh", "uyanhanh123"); // Put you SSID and Password here

	// Optional: Change IP addresses (and disable DHCP)
	// WifiAccessPoint.setIP(IPAddress(192, 168, 4, 1));
	// WifiStation.setIP(IPAddress(192, 168, 2, 117));   
    
	// Run WEB server on system ready
	System.onReady(startServers);
}
